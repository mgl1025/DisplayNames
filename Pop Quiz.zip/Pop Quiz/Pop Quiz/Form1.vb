﻿Public Class Form1



    Private Sub Main()

        Dim f As String = txtFirstName.Text
        Dim m As String = txtMiddleName.Text
        Dim l As String = txtLastName.Text
        Dim fn As String = txtNames.Text

        Me.Cat() = txtNames.Text

    End Sub

    Private Function GetInfo(f As String, m As String, l As String)



    End Function

    Private Function Cat(f As String, m As String, l As String, fn As String)

        Dim output As String

        output = (f & " " & m & " " & l & DateTime.Now)

        Return output
    End Function


    '--------Event Handler----------------------------------------
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Main()

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
