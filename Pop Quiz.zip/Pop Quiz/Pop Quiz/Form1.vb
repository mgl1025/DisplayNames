﻿Public Class Form1


    Private Sub Main()

        Dim f As String = txtFirstName.Text
        Dim m As String = txtMiddleName.Text
        Dim l As String = txtLastName.Text

        Dim output As String = Cat(f, m, l)
        output &= "Hello" & vbNewLine
        output &= "Your user name is" & vbNewLine
        output &= getInfo(f, m, l)

        txtNames.Text = output

    End Sub

    Private Function getInfo(f As String, m As String, l As String)

        Dim info As String = My.User.Name & vbNewLine
        info &= Now.Date.ToShortDateString()

        Return info

    End Function

    Private Function Cat(f As String, m As String, l As String)

        Dim n As String

        n = " " & f & " " & m & " " & l & " "

        Return n

    End Function

    '--------Event Handler----------------------------------------
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Main()

    End Sub

End Class
