﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.dfd = New System.Windows.Forms.Label()
        Me.dd = New System.Windows.Forms.Label()
        Me.dddd = New System.Windows.Forms.Label()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.txtMiddleName = New System.Windows.Forms.TextBox()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.txtNames = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(119, 110)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'dfd
        '
        Me.dfd.AutoSize = True
        Me.dfd.Location = New System.Drawing.Point(20, 31)
        Me.dfd.Name = "dfd"
        Me.dfd.Size = New System.Drawing.Size(57, 13)
        Me.dfd.TabIndex = 1
        Me.dfd.Text = "First Name"
        '
        'dd
        '
        Me.dd.AutoSize = True
        Me.dd.Location = New System.Drawing.Point(116, 31)
        Me.dd.Name = "dd"
        Me.dd.Size = New System.Drawing.Size(69, 13)
        Me.dd.TabIndex = 2
        Me.dd.Text = "Middle Name"
        '
        'dddd
        '
        Me.dddd.AutoSize = True
        Me.dddd.Location = New System.Drawing.Point(211, 31)
        Me.dddd.Name = "dddd"
        Me.dddd.Size = New System.Drawing.Size(58, 13)
        Me.dddd.TabIndex = 3
        Me.dddd.Text = "Last Name"
        '
        'txtFirstName
        '
        Me.txtFirstName.Location = New System.Drawing.Point(12, 62)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(66, 20)
        Me.txtFirstName.TabIndex = 4
        '
        'txtMiddleName
        '
        Me.txtMiddleName.Location = New System.Drawing.Point(119, 62)
        Me.txtMiddleName.Name = "txtMiddleName"
        Me.txtMiddleName.Size = New System.Drawing.Size(66, 20)
        Me.txtMiddleName.TabIndex = 5
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(214, 62)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(66, 20)
        Me.txtLastName.TabIndex = 6
        '
        'txtNames
        '
        Me.txtNames.Location = New System.Drawing.Point(12, 153)
        Me.txtNames.Multiline = True
        Me.txtNames.Name = "txtNames"
        Me.txtNames.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtNames.Size = New System.Drawing.Size(294, 112)
        Me.txtNames.TabIndex = 7
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(350, 311)
        Me.Controls.Add(Me.txtNames)
        Me.Controls.Add(Me.txtLastName)
        Me.Controls.Add(Me.txtMiddleName)
        Me.Controls.Add(Me.txtFirstName)
        Me.Controls.Add(Me.dddd)
        Me.Controls.Add(Me.dd)
        Me.Controls.Add(Me.dfd)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents dfd As Label
    Friend WithEvents dd As Label
    Friend WithEvents dddd As Label
    Friend WithEvents txtFirstName As TextBox
    Friend WithEvents txtMiddleName As TextBox
    Friend WithEvents txtLastName As TextBox
    Friend WithEvents txtNames As TextBox
End Class
